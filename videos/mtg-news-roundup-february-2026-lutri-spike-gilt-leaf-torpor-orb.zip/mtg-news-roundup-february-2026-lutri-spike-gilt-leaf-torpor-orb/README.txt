========================================
HEYGEN VIDEO KIT
========================================

Article: First up—Lutri, the Spellchaser...
Scenes:  4
Words:   119
Est:     ~47 seconds

----------------------------------------
HEYGEN WEB STUDIO SETTINGS
----------------------------------------
Format:    9:16 vertical (1080x1920)
Avatar:    Your custom avatar (heygen-1)
Captions:  ON
Speed:     1.1x

========================================
SCENES — Copy each into a separate scene
========================================

--- SCENE 1 of 4 ---

Background image: card-art/lutri-the-spellchaser.jpg
Card shown:       Lutri, the Spellchaser
Avatar visible:   YES (small circle, bottom-right)
Est duration:     ~12s (30 words)

SPOKEN TEXT (paste into voice input):
First up—Lutri, the Spellchaser. This otter went from bulk to seventy-two dollars overnight. The Commander Format Panel unbanned it as your commander. The Halo Foil from Multiverse Legends? Seventy-two dollars.

--- SCENE 2 of 4 ---

Background image: card-art/gilt-leaf-palace.jpg
Card shown:       Gilt-Leaf Palace
Avatar visible:   NO (hide avatar, full-screen card art)
Est duration:     ~12s (31 words)

SPOKEN TEXT (paste into voice input):
Next—Gilt-Leaf Palace. This Lorwyn tribal land was supposed to get reprinted in Lorwyn Eclipsed. It didn't. Collectors panicked. Four dollars last week. Now? Eighteen and climbing. Old-border printings are spec targets.

--- SCENE 3 of 4 ---

Background image: card-art/high-perfect-morcant.jpg
Card shown:       High Perfect Morcant
Avatar visible:   NO (hide avatar, full-screen card art)
Est duration:     ~12s (30 words)

SPOKEN TEXT (paste into voice input):
Why is Gilt-Leaf Palace spiking? Meet High Perfect Morcant. This new legend is driving Elfball dominance. When a commander can spike a twenty-year-old land, you know the deck is real.

--- SCENE 4 of 4 ---

Background image: card-art/torpor-orb.jpg
Card shown:       Torpor Orb
Avatar visible:   YES (small circle, bottom-right)
Est duration:     ~11s (28 words)

SPOKEN TEXT (paste into voice input):
Finally—the sideboard king. Torpor Orb. Pro Tour Richmond was packed with ETB decks. Veterans reached for this. It climbed to twelve dollars and it's now a Standard mainstay.

========================================
FULL SCRIPT (for reference)
========================================

First up—Lutri, the Spellchaser. This otter went from bulk to seventy-two dollars overnight. The Commander Format Panel unbanned it as your commander. The Halo Foil from Multiverse Legends? Seventy-two dollars. Next—Gilt-Leaf Palace. This Lorwyn tribal land was supposed to get reprinted in Lorwyn Eclipsed. It didn't. Collectors panicked. Four dollars last week. Now? Eighteen and climbing. Old-border printings are spec targets. Why is Gilt-Leaf Palace spiking? Meet High Perfect Morcant. This new legend is driving Elfball dominance. When a commander can spike a twenty-year-old land, you know the deck is real. Finally—the sideboard king. Torpor Orb. Pro Tour Richmond was packed with ETB decks. Veterans reached for this. It climbed to twelve dollars and it's now a Standard mainstay.

========================================
CARD ART FILES (in card-art/ folder)
========================================

  Gilt-Leaf Palace  ->  card-art/gilt-leaf-palace.jpg
  Lutri, the Spellchaser  ->  card-art/lutri-the-spellchaser.jpg
  Torpor Orb  ->  card-art/torpor-orb.jpg
  High Perfect Morcant  ->  card-art/high-perfect-morcant.jpg
